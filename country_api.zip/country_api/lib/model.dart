
class Country {
  String code;
  String name;
  String? capital;
  String? currency;
  String? native;
  String? phone;
  String? emoji;

  Country.fromJson(Map<String, dynamic> json)
      : code = json["code"],
        name = json["name"],
        capital = json["capital"],
        currency = json["currency"],
        native = json["native"],
        phone = json["phone"],
        emoji = json["emoji"];
}
/*
class Country {
  String name;
  String capital;
  String code;
  String native;
  String currency;
  String phone;
  String emoji;
  Continent continent;

  Country({
    required this.name,
    required this.capital,
    required this.code,
    required this.native,
    required this.currency,
    required this.phone,
    required this.emoji,
    required this.continent,
  });

  factory Country.fromJson(Map<String, dynamic> json) {
    return Country(
      name: json['name'],
      capital: json['capital'] ?? '',
      code: json['code'] ?? '',
      native: json['native'] ?? '',
      currency: json['currency'] ?? '',
      phone: json['phone'] ?? '',
      emoji: json['emoji'] ?? '',
      continent: Continent.fromJson(json['continent'] ?? {}),
    );
  }
}

class Continent {
  String name;

  Continent({
    required this.name,
  });

  factory Continent.fromJson(Map<String, dynamic> json) {
    return Continent(
      name: json['name'] ?? 'NULL',
    );
  }
}

*/