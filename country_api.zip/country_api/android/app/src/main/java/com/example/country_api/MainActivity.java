package com.example.country_api;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
